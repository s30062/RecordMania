CREATE PROCEDURE NotifyInactiveClients
AS
BEGIN
    DECLARE @clientId INT, @clientName NVARCHAR(35), @clientSurname NVARCHAR(35), @notificationId INT;

    -- Cursor to select inactive clients who haven't booked in the last 30 days
    DECLARE inactive_clients CURSOR FOR
        SELECT c.id, c.Name, c.Surname
        FROM Clients c
        WHERE NOT EXISTS (
            SELECT 1
            FROM Booking b
            WHERE b.clients_id = c.id
            AND b.booking_date > DATEADD(DAY, -30, GETDATE())
        );

    OPEN inactive_clients;
    FETCH NEXT FROM inactive_clients INTO @clientId, @clientName, @clientSurname;

    WHILE @@FETCH_STATUS = 0
    BEGIN
        -- Generate a new notification_id (if needed, using a sequential value or NEWID() for GUID)
        SET @notificationId = (SELECT ISNULL(MAX(notification_id), 0) + 1 FROM Notification);

        -- Insert a notification with the generated notification_id
        INSERT INTO Notification (notification_id, Clients_id, message, date_sending)
        VALUES (@notificationId, @clientId, 'We miss you! Book a class today!', GETDATE());

        FETCH NEXT FROM inactive_clients INTO @clientId, @clientName, @clientSurname;
    END;

    CLOSE inactive_clients;
    DEALLOCATE inactive_clients;
END;
go

