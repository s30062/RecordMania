CREATE PROCEDURE GetClientsByClass
    @ClassID INT
AS
BEGIN
    IF NOT EXISTS (
        SELECT 1 FROM Yoga_Class
        WHERE Class_id = @ClassID
    )
    BEGIN
        PRINT 'The specified class does not exist.';
        RETURN;
    END;

    SELECT c.Name, c.Surname, c.phone_number, b.presence
    FROM Clients c
    INNER JOIN Booking b ON c.id = b.clients_id
    WHERE b.class_id = @ClassID;

    SELECT
        COUNT(CASE WHEN b.presence = 'P' THEN 1 END) AS PresentCount,
        COUNT(CASE WHEN b.presence = 'A' THEN 1 END) AS AbsentCount
    FROM Booking b
    WHERE b.class_id = @ClassID;
END;
go

