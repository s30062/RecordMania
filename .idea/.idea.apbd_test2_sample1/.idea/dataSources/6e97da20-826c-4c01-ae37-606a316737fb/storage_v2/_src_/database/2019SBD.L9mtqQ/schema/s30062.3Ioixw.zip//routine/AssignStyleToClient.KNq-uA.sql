CREATE PROCEDURE AssignStyleToClient
    @ClientID INT,
    @StyleID INT
AS
BEGIN
    BEGIN TRY
        BEGIN TRANSACTION;

        -- Check if the client exists
        IF NOT EXISTS (SELECT 1 FROM Clients WHERE id = @ClientID)
        BEGIN
            PRINT 'The specified client does not exist.';
            ROLLBACK TRANSACTION;
            RETURN;
        END;

        -- Check if the style exists
        IF NOT EXISTS (SELECT 1 FROM Style WHERE id = @StyleID)
        BEGIN
            PRINT 'The specified style does not exist.';
            ROLLBACK TRANSACTION;
            RETURN;
        END;

        -- Check if the client is already assigned to this style
        IF EXISTS (
            SELECT 1 FROM Clients_Style
            WHERE Clients_id = @ClientID AND Style_id = @StyleID
        )
        BEGIN
            PRINT 'The client is already assigned to this style.';
            ROLLBACK TRANSACTION;
            RETURN;
        END;

        -- Assign the style
        INSERT INTO Clients_Style (Clients_id, Style_id)
        VALUES (@ClientID, @StyleID);

        -- Calculate the next notification_id
        DECLARE @NextNotificationID INT;
        SELECT @NextNotificationID = ISNULL(MAX(notification_id), 0) + 1 FROM Notification;

        -- Notify the client
        INSERT INTO Notification (notification_id, Clients_id, message, date_sending)
        VALUES (
            @NextNotificationID,
            @ClientID,
            CONCAT('You have been assigned to the style: ', (SELECT name FROM Style WHERE id = @StyleID)),
            GETDATE()
        );

        COMMIT TRANSACTION;
        PRINT 'Style assigned to the client and notification sent successfully.';
    END TRY
    BEGIN CATCH
        ROLLBACK TRANSACTION;
        PRINT 'An error occurred while assigning the style.';
        THROW;
    END CATCH;
END;
go

