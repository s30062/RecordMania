CREATE PROCEDURE AssignInstructor
    @ClassId INT,
    @InstructorId INT
AS
BEGIN
    INSERT INTO Instructor_Classes (Instructors_id, Yoga_class_id)
    VALUES (@InstructorId, @ClassId);

    PRINT 'Instructor assigned successfully.';
END;
go

